User Authentication using JWT (JSON Web Token) in Node.js (Express Framework ) and Angular.js

### Install an app

Run the following command in root directory of an app in command prompt.

###### *Install node packages*

npm install

bower install | sudo bower install --allow-root 

Run the following command in root directory of an app in command prompt.

node server.js

You can see the port number in command prompt after sucessfull run

You can change the settings in server/config/config.js file

set email and password into config file
