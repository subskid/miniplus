
 const mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    autoIncrement = require('mongoose-auto-increment'),
    db = require('../config/db').db;
    uniqueValidator = require('mongoose-unique-validator');

autoIncrement.initialize(db);

/**
 * @module  User
 * @description contain the details of Attribute
 */


var User = new Schema({

  name: String,

  email: { type: String, unique: true },

  roles: [{ type: 'String' }],

  isVerified: { type: Boolean, default: false },

  password: String,

  passwordResetToken: String,

  passwordResetExpires: Date

});


User.plugin(autoIncrement.plugin, {
    model: 'user',
    field: '_id'
});

(uniqueValidator);

User.statics = {
    saveUser: function(requestData, callback) {
        this.create(requestData, callback);
    },
    findUserUpdate: function(query, user, callback) {
        this.findOneAndUpdate(query, user, callback);
    },
    updateUser: function(user, callback) {
        user.save(callback);
    },

    findUser: function(query, callback) {
        this.findOne(query, callback);
    },

    findUserByIdAndUserName: function(id, username, callback) {
        this.findOne({ username: username, _id: id }, callback);
    }
}

var user = mongoose.model('user', User);


const token = new Schema({

    _userId: { type: mongoose.Schema.Types.ObjectId, required: true, ref: 'User' },

    token: { type: String, required: true },

    createdAt: { type: Date, required: true, default: Date.now, expires: 43200 }

});


var token = mongoose.model('token', Token);
 
/** export schema */
module.exports = {
    User: user
,
    Token: token
};
