'use strict'; 
const Common = require('../config/common')
const Config = require('../config/config')
const Jwt = require('jsonwebtoken')
const user = require('./user.server.model').User
const token = require('./user.server.model').Token
const privateKey = Config.key.privateKey
const async = require('async')

exports.register = (req, res, next) => {

  req.assert('name', 'Name cannot be blank').notEmpty();

  req.assert('email', 'Email is not valid').isEmail();

  req.assert('email', 'Email cannot be blank').notEmpty();

  req.assert('password', 'Password must be at least 4 characters long').len(4);

  req.sanitize('email').normalizeEmail({ remove_dots: false });

 

  // Check for validation errors    

  var errors = req.validationErrors();

  if (errors) { return res.status(400).send(errors); }

    //encrypt the password

	   var req.body.password = Common.encrypt(req.body.password);

  // Make sure this account doesn't already exist

  user.findUser({ email: req.body.email }, function (err, user) {

    // Make sure user doesn't already exist

    if (user) return res.status(400).send({ msg: 'The email address you have entered is already associated with another account.' });
});

    // Create and save the user

           user.saveUser(req.body, (err, user) => {
                

        if (err) { return res.status(500).send({ msg: err.message }); }

 

        // Create a verification token for this user

        var token = new token({ _userId: user._id, token: crypto.randomBytes(16).toString('hex') });

        // Save the verification token

        token.save(function (err) {

            if (err) { return res.status(500).send({ msg: err.message }); }
 
        });

     //send verification email
        
             Common.sentMailVerificationLink(user, token.token, (err, result) => {
  
              
                if (err) { return res.status(500).send({ msg: err.message }); }

                res.status(200).send('A verification email has been sent ' + user.email + '.');
            });
}

    //Login controller

exports.login = (req, res, next) => {

    req.assert('email', 'Email is not valid').isEmail();

    req.assert('email', 'Email cannot be blank').notEmpty();

    req.assert('password', 'Password cannot be blank').notEmpty();

    req.sanitize('email').normalizeEmail({ remove_dots: false });

 

    // Check for validation error

    var errors = req.validationErrors();

    if (errors) return res.status(400).send(errors);

     //check for correct email

	User.findUser({email: req.body.email}, (err, user) => {

        if (err) {
            return res.status(500).send(`Oh uh, something went wrong`);
        }
      
        if (!user) return res.status(401).send({ msg: 'The email address ' + req.body.email + ' is not associated with any account. Double-check your email address and try again.'});

        //check for correct password

            if (req.body.password !=== Common.decrypt(user.password)) 
          return res.status(401).send({ msg: 'Incorrect password'});


        //check if user is verified

                if(!user.isVerified)
                	return res.status(401).send(`Your email address is not verified. please verify your email address to proceed`);
                
                
	                var tokenData = {
	                    username: user.username,
	                    id: user._id
	                };
	                var result = {
	                    username: user.username,
	                    token: Jwt.sign(tokenData, privateKey)
	                };

	                return res.json(result);
                
            }
}

exports.forgotPassword = (req, res) => {

                   req.assert('email', 'Email cannot be blank').notEmpty();

    req.assert('email', 'Password cannot be blank').isEmail();

    req.sanitize('email').normalizeEmail({ remove_dots: false });

 

    // Check for validation error

    var errors = req.validationErrors();

    if (errors) return res.status(400).send(errors);

           User.findUser({email: req.body.email}, (err, user) => {

    if (err) {
            return res.status(500).send(`Oh uh, something went wrong`);
        }
      
        if (!user) return res.status(401).send({ msg: 'The email address ' + req.body.email + ' is not associated with any account. Double-check your email address and try again.'});

        function(user, callback) {
            let tokenData = {
                email: user.email,
                id: user._id
            }
            Common.sentMailForgotPassword(user, Jwt.sign(tokenData, privateKey), (err, result) => {
                if (err) {
            return res.status(500).send(`Oh uh, something went wrong`);
        }
      
        if (result) return res.status(200).send({ msg: 'Reset password link sent to your email address'});
    });
}

exports.changePassword = (req, res) => {
   
                   req.assert('email', 'Email cannot be blank').notEmpty();

    req.assert('email', 'Password cannot be blank').isEmail();

    req.sanitize('email').normalizeEmail({ remove_dots: false });

 

    // Check for validation error

    var errors = req.validationErrors();

if (errors) return res.status(400).send(errors);
       User.findUser({password: req.body.oldPassword}, (err, user) => {

    if (err) {
            return res.status(500).send(`Oh uh, something went wrong`);
        }
      
        if (!user) return res.status(401).send({ msg: 'Incorrect old password.'});


                 if (req.body.newPassword !== req.body.confirmNew){
                    return res.status(400).send(`Password Mismatch`);
                }
                else{
                    user.password = Common.encrypt(req.body.newPassword);
                    User.updateUser(user, (err, user) => {
                        if (!err) {
                            return res.json({message: `password changed successfully`});
                        }
                        else{ return res.status(500).send(`Oh uh, something went wrong`); }     
                    })
                
            }) 
        }

exports.verifyEmail = (req, res) => {
	Jwt.verify(req.body.token, privateKey, (err, decoded) => {
        if(err)  return res.status(500).send(`Oh uh, something went wrong`);
        else{
            User.findUserByIdAndUserName(decoded.id, decoded.username, (err, user) => {
                if (err) {
                    return res.status(500).send(`Oh uh, something went wrong`);
                }
                else if (user == null){
                    return res.status(422).send(`Email not recognised`);
                }
                else if (user.isVerified === true){
                    return res.json({message: `account is already verified`});
                }
                else{
                    user.isVerified = true;
                    User.updateUser(user, (err, user) => {
                        if (!err) {
                            return res.json({message:`account sucessfully verified`});
                        }
                        else{ return res.status(500).send(`Oh uh, something went wrong`); }     
                    })
                }
            })   
        }    
    })
}
